/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset2;

import static Dataset2.RuleSet.*;
import static Dataset2.ConverttoString.*;

/**
 *
 * @author Igneel
 */
public class GA {

    static int RuleSet;
    static String[] rules, conditions, result;
    static String stringData = "";

    public static void main(String[] args) {
        RuleSet = 7;
        Dataset();

        Fitness.setSolution(stringData);
        System.out.print("Dataset: ");
        for (int i = 0; i < rules.length; i++) {
            System.out.print("\n" + rules[i] + "  ");
        }
        System.out.println("");

        Population myPopulation = new Population(100, true);//Population

        System.out.println("Generated random Strings " + myPopulation.getFittest());
        System.out.println("---------------------------------------------------------");

        int generationCounter = 0;//generation counter

        //loops through until maximum fitness is reached
        while (myPopulation.getFittest().getFitness() < Fitness.getMaximumFitness()) {
            generationCounter = 100; //generations
            System.out.println("---------------------------------------------------------");
            System.out.println("Generations: " + generationCounter + "\n"
                    + "Fittness: " + myPopulation.getFittest().getFitness());
            int a = 0;
            while (a < myPopulation.individual.length) {
                a++;
                for (int b = 1; b < myPopulation.individual.length; b++) {
                    int c = b - 1;
                    if (myPopulation.individual[c].getFitness() <= myPopulation.individual[b].getFitness()) {
                        Individual temp = myPopulation.individual[c];
                        myPopulation.individual[c] = myPopulation.individual[b];
                        myPopulation.individual[b] = temp;
                    }
                }
            }

            System.out.println("---------------------------------------------------------");

            System.out.println("Best Fitness: " + myPopulation.individual[1].getFitness());
            System.out.println("Worst Fitness: " + myPopulation.individual[49].getFitness());
            System.out.println("Average Fitness: " + myPopulation.individual[25].getFitness());

            System.out.println("");

            System.out.print("Rules for current gene: " + " \n");
            for (int j = 0; j < ruleRandom.length; j++) {
                System.out.print(conditionRandom[j] + " " + resultRandom[j] + "  " + "\n");
            }
            System.out.println("");

            myPopulation = Evolution.evolvePopulation(myPopulation); //separate class for rate altering test fitness now
        }
        generationCounter++;
        System.out.println("The correct solution has been found.");
        System.out.println("Fitness: " + myPopulation.getFittest().getFitness());
        System.out.println("Generations: " + generationCounter);
        System.out.println(" ");
        //now print out matched
        System.out.println("Data to match: ");
        for (int i = 0; i < rules.length; i++) {
            System.out.print(conditions[i] + " " + result[i] + " " + "\n");;
        }

        //print out matched rules
        System.out.println(" ");
        System.out.println("Rules to match are: ");
        for (int i = 0; i < ruleRandom.length; i++) {
            System.out.print(conditionRandom[i] + " " + resultRandom[i] + " " + "\n");;
        }
    }
}
