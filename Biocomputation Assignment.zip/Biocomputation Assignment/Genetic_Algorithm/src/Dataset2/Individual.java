/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset2;

import java.util.Random;

/**
 *
 * @author Igneel
 */
public class Individual {

    static int geneLength = 192;
    private int[] genes = new int[geneLength];
    private int fitness = 0;
    Random rand = new Random();

    // Create a random individual
    public void generateIndividual() {
        int i = 0;
        while (i < size()) {
            if (i % 5 == 0) {
                int gene = (int) Math.round(Math.random());

                genes[i] = gene;
            } else {
                byte gene = 0;
                genes[i] = gene;
            }
            i++;
        }
    }

    public static void setDefaultGeneLength(int length) {
        geneLength = length;
    }

    public int getGene(int index) {
        return genes[index];
    }

    public void setGene(int index, byte value) {
        genes[index] = value;
        fitness = 0;
    }

    public int size() {
        return genes.length;
    }

    public int getFitness() {
        if (fitness == 0) {
            fitness = Fitness.getTheFitness(this);
        }
        return fitness;
    }

    @Override
    public String toString() {
        java.lang.String geneString = "";
        int i = 0;
        while (i < size()) {
            geneString += getGene(i);
            i++;
        }
        return geneString;
    }
}
