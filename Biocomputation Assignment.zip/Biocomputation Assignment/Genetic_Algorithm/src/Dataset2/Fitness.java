/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset2;

import static Dataset2.Individual.*;
import static Dataset2.ConverttoString.*;
import static Dataset2.GA.*;

/**
 *
 * @author Igneel
 */
public class Fitness {

    static byte[] solution = new byte[geneLength];
    static boolean passed;
    static boolean OutputMatched = false;

    public static void setSolution(byte[] newSolution) {
        solution = newSolution;
    }

    // Method to set candidate solution with strings of 0s and 1s
    static void setSolution(java.lang.String newSolution) {
        solution = new byte[newSolution.length()];
        // loop through each character of the string and save it in the byte array
        for (int i = 0; i < newSolution.length(); i++) {
            java.lang.String character = newSolution.substring(i, i + 1);
            if (character.contains("0") || character.contains("1")) {
                solution[i] = Byte.parseByte(character);
            } else {
                solution[i] = 0;
            }
        }
    }

    static int getTheFitness(Individual individual) {
        int fitness = 0;
        currentGenes = individual.toString();
        RandomStringToRules();

        for (int k = 0; k < conditions.length; k++) {
            for (int j = 0; j < conditionRandom.length; j++) {
                passed = true;

                for (int i = 0; i < conditionRandom[i].length(); i++) {
                    if (passed == true) {
                        if (conditions[k].charAt(i) != conditionRandom[j].charAt(i)) {
                            if (conditionRandom[j].charAt(i) != '2') {
                                passed = false;
                            }
                        }
                    }
                }
                if (passed == true) {
                    if (result[k].equals(resultRandom[j])) {
                        fitness++;
                    }
                    break;

                }
            }
        }
        return fitness;
    }

    static int getMaximumFitness() {
        int maxFitness = conditions.length;
        return maxFitness;
    }
}
