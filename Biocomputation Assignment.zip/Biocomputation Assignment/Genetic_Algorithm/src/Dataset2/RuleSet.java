/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset2;

import java.util.Scanner;
import static Dataset2.GA.*;

/**
 *
 * @author Igneel
 */
public class RuleSet {

    static Scanner datatset = new Scanner(RuleSet.class.getResourceAsStream("data2.txt"));
    static String set1 = "";

    static public void Dataset() {

        rules = new String[64];
        conditions = new String[64];
        result = new String[64];

        //Reads the file and replaces the spaces
        for (int i = 0; i < 64; i++) {
            rules[i] = datatset.nextLine().replaceAll("\\s+", "");
        }

        //Joins the lines together to create one whole string
        for (int j = 0; j < rules.length; j++) {
            stringData += rules[j];
        }

        //Takes every 6th bit and puts it into the result array
        for (int k = 0; k < rules.length; k++) {
            result[k] = String.valueOf(rules[k].charAt(6));
        }

        for (int l = 0; l < rules.length; l++) {
            set1 = "";
            for (int m = 0; m < 6; m++) {
                set1 += String.valueOf(rules[l].charAt(m));
                conditions[l] = set1;
            }

        }

    }
}
