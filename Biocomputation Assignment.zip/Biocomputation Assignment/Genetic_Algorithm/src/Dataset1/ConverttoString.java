/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset1;

import static Dataset1.Individual.*;
import static Dataset1.GA.*;

/**
 *
 * @author Igneel
 */
public class ConverttoString {

    //Sets must be string for calc
    static java.lang.String currentGenes = "";
    static java.lang.String set = "";
    static java.lang.String set1 = "";
    static java.lang.String[] ruleRandom = new java.lang.String[geneLength / RuleSet];//Rules for random
    static java.lang.String[] resultRandom = new java.lang.String[geneLength / RuleSet];//Output for randoms
    static java.lang.String[] conditionRandom = new java.lang.String[geneLength / RuleSet];//condition for randoms

    public static void RandomStringToRules() {
        //Breaks the randomly genereated string in groups of 6 using modulus
        int k = 0;
        for (int i = 1; i < currentGenes.length() + 1; i++) {
            set += currentGenes.charAt(i - 1);
            int test = i % RuleSet;
            if (test == 0) {
                ruleRandom[k] = set;
                k++;
                set = "";
            }
        }

        //generates random strings for each rule
        for (int j = 0; j < ruleRandom.length; j++) {
            resultRandom[j] = java.lang.String.valueOf(ruleRandom[j].charAt(RuleSet - 1));
        }

        for (int l = 0; l < ruleRandom.length; l++) {
            set1 = "";
            for (int m = 0; m < RuleSet - 1; m++) {

                set1 += java.lang.String.valueOf(ruleRandom[l].charAt(m));
                conditionRandom[l] = set1;

            }

        }
    }
}
