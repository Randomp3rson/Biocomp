/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset1;

/**
 *
 * @author Igneel
 */
public class Evolution {

    private static double crossOverRate = 0.5;
    private static double mutationRate = 0.0015;
    private static int tourament = 2;
    private static boolean DominateIndiv = true; // choosing best

    // Evolve a population
    public static Population evolvePopulation(Population pop) {
        Population newPopulation = new Population(pop.populationSize(), false);

        // Keep our best individual
        if (DominateIndiv) {
            newPopulation.saveIndividual(0, pop.getFittest());
        }

        // Crossover population
        int DominateIndivOffset;
        if (DominateIndiv) {
            DominateIndivOffset = 1;
        } else {
            DominateIndivOffset = 0;
        }
        // Loop over the population size and create new individuals with crossover
        for (int i = DominateIndivOffset; i < pop.populationSize(); i++) {
            Individual indiv1 = tournamentSelection(pop);
            Individual indiv2 = tournamentSelection(pop);
            Individual newIndiv = crossover(indiv1, indiv2);
            newPopulation.saveIndividual(i, newIndiv);
        }

        // Mutate population
        for (int i = DominateIndivOffset; i < newPopulation.populationSize(); i++) {
            mutation(newPopulation.getIndividual(i));
        }

        return newPopulation;
    }

    // Crossover individuals
    private static Individual crossover(Individual Indi1, Individual Indi2) {
        //parse solution 
        Individual newSolution = new Individual();
        // Loop through genes
        for (int i = 0; i < Indi1.size(); i++) {
            // Crossover
            if (Math.random() <= crossOverRate) {
                newSolution.setGene(i, (byte) Indi1.getGene(i));
            } else {
                newSolution.setGene(i, (byte) Indi2.getGene(i));
            }
        }
        return newSolution;
    }

    // Mutate an individual
    private static void mutation(Individual indiv) {
        // Loop through genes
        for (int i = 0; i < indiv.size(); i++) {
            if (Math.random() <= mutationRate) {
                byte gene = (byte) Math.floor(Math.random() * 3);
                indiv.setGene(i, gene);
            }
        }
    }

    // Select individuals for crossover
    private static Individual tournamentSelection(Population pop) {
        // Create a tournament population
        Population tournament = new Population(tourament, false);
        // For each place in the tournament get a random individual
        for (int i = 0; i < tourament; i++) {
            int randomId = (int) (Math.random() * pop.populationSize());
            tournament.saveIndividual(i, pop.getIndividual(randomId));
        }
        Individual fittest = tournament.getFittest();
        return fittest; //retrieve fittest
    }
}
