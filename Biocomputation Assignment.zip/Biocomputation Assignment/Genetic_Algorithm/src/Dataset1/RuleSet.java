/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset1;

import java.util.Scanner;
import static Dataset1.GA.*;

/**
 *
 * @author Igneel
 */
public class RuleSet {

    static Scanner datatset = new Scanner(RuleSet.class.getResourceAsStream("data1.txt"));
    static String set1 = "";

    static public void Dataset() {
        rules = new String[32];
        conditions = new String[32];
        result = new String[32];

        //Reads the file and replaces the spaces
        int i = 0;
        while ( i < 32) {
            rules[i] = datatset.nextLine().replaceAll("\\s+", "");
             i++;
        }
        //Joins the lines together to create one whole string
        int j = 0;
        while ( j < rules.length) {
            stringData += rules[j];
            j++;
        }
        //Takes every 6th bit and puts it into the result array
        int k = 0;
        while (k < rules.length) {
            result[k] = String.valueOf(rules[k].charAt(5));
            k++;
        }
        
        for (int l = 0; l < rules.length; l++) {
            set1 = "";
            int m = 0;
            while ( m < 5) {
                set1 += String.valueOf(rules[l].charAt(m));
                conditions[l] = set1;
                 m++;
            }

        }
    }
}
