/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dataset1;

/**
 *
 * @author Igneel
 */
public class Population {

    Individual[] individual;

    //Create population
    public Population(int popSize, boolean initialize) {
        individual = new Individual[popSize];
        //Initialize population
        if (initialize) {
            //Create individuals
            int i = 0;
            while ( i < populationSize()) {
                Individual newIndividual = new Individual();
                newIndividual.generateIndividual();
                saveIndividual(i, newIndividual);
                 i++;
            }
        }
    }

    public Individual getIndividual(int index) {
        return individual[index];
    }

    public Individual getFittest() {
        Individual fittest = individual[0];
        //Find the fittest individual
        for (int i = 0; i < populationSize(); i++) {
            if (fittest.getFitness() <= getIndividual(i).getFitness()) {
                fittest = getIndividual(i);
            }
        }
        return fittest;
    }

    public int populationSize() {
        return individual.length;

    }

    //Saving the individual
    public void saveIndividual(int index, Individual indiv) {
        individual[index] = indiv;
    }
}
